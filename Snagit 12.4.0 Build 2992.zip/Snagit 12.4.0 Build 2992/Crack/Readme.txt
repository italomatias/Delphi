- Install the application
- Use "Keygen_DownLoadLy.iR.exe" to register the application

WWW.DOWNLOADLY.IR